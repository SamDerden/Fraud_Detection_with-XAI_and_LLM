import numpy as np, pandas as pd, json, hashlib
from pathlib import Path
from collections import deque, defaultdict
from datetime import datetime, timedelta, timezone

OUT=Path(__file__).resolve().parent
SEED=20261120
rng=np.random.default_rng(SEED)
N=7000; USERS=220; START=datetime(2026,1,1,tzinfo=timezone.utc)
# Distinct client spending and activity profiles, persistent device/merchant preferences.
profiles=[]
for u in range(USERS):
    profiles.append(dict(uid=f'usr_{u:04d}', country=rng.choice(['RU','KZ','BY','UZ','TR'],p=[.78,.08,.06,.05,.03]),
       channel=rng.choice(['mobile','web','pos'],p=[.58,.22,.20]), median=float(rng.lognormal(7.6,.9)),
       active=float(rng.lognormal(0,.65)), home_merchants=rng.choice(450,size=7,replace=False).tolist(),
       base_device=f'dev_{u:04d}_main', compromised=bool(rng.random()<.18)))
# Generate chronological events for 155 days; first 45 days are history only.
rows=[]; seq=0
for day in range(155):
    # vary activity smoothly, but ensure enough warm-up transactions
    for u,p in enumerate(profiles):
        count=int(rng.poisson(p['active']*.33))
        for _ in range(count):
            t=START+timedelta(days=day,seconds=int(rng.integers(0,86400)))
            unusual=bool(rng.random()<.075)
            is_fraud=int(rng.random() < (.42 if unusual and p['compromised'] else .28 if unusual else .055 if p['compromised'] else .025))
            # Scenarios overlap, no perfect deterministic label signal.
            if is_fraud and rng.random()<.58: unusual=True
            country=p['country'] if not unusual or rng.random()<.48 else rng.choice(['RU','KZ','BY','UZ','TR','AE'])
            channel=p['channel'] if rng.random()<.85 else rng.choice(['mobile','web','pos'])
            merchant=int(rng.choice(p['home_merchants'])) if rng.random()<(.84 if not unusual else .37) else int(rng.integers(0,450))
            device=p['base_device'] if not unusual or rng.random()<.40 else f'dev_{u:04d}_alt_{int(rng.integers(0,5))}'
            amount=round(float(np.clip(p['median']*rng.lognormal(.0 if not unusual else .7,.78),50,300000)),2)
            rows.append(dict(transaction_id=f'txn_{seq:07d}',user_id=p['uid'],merchant_id=f'mrc_{merchant:04d}',device_id=device,
                amount=amount,currency='RUB',timestamp=t,country=country,channel=channel,is_fraud=is_fraud))
            seq+=1
rows.sort(key=lambda x:(x['timestamp'],x['transaction_id']))
# Target exactly 7000 records after warm-up, adjusting the activity horizon by deterministic extension if necessary.
cutoff=START+timedelta(days=45)
pre=[r for r in rows if r['timestamp']<cutoff]
post=[r for r in rows if r['timestamp']>=cutoff]
if len(post)<N:
    # Increase simulation horizon with identical generator distributions.
    day=155
    while len(post)<N:
        for u,p in enumerate(profiles):
            for _ in range(int(rng.poisson(p['active']*.33))):
                t=START+timedelta(days=day,seconds=int(rng.integers(0,86400)))
                unusual=bool(rng.random()<.075)
                is_fraud=int(rng.random()<(.42 if unusual and p['compromised'] else .28 if unusual else .055 if p['compromised'] else .025))
                if is_fraud and rng.random()<.58: unusual=True
                country=p['country'] if not unusual or rng.random()<.48 else rng.choice(['RU','KZ','BY','UZ','TR','AE'])
                channel=p['channel'] if rng.random()<.85 else rng.choice(['mobile','web','pos'])
                merchant=int(rng.choice(p['home_merchants'])) if rng.random()<(.84 if not unusual else .37) else int(rng.integers(0,450))
                device=p['base_device'] if not unusual or rng.random()<.40 else f'dev_{u:04d}_alt_{int(rng.integers(0,5))}'
                amount=round(float(np.clip(p['median']*rng.lognormal(.0 if not unusual else .7,.78),50,300000)),2)
                post.append(dict(transaction_id=f'txn_{seq:07d}',user_id=p['uid'],merchant_id=f'mrc_{merchant:04d}',device_id=device,
                    amount=amount,currency='RUB',timestamp=t,country=country,channel=channel,is_fraud=is_fraud))
                seq+=1
        day+=1
post.sort(key=lambda x:(x['timestamp'],x['transaction_id']))
target=post[:N]; allrows=sorted(pre+target,key=lambda x:(x['timestamp'],x['transaction_id']))
# Calculate only prior-event rolling features; events are appended after feature calculation.
history=defaultdict(deque); first_seen={}; enriched=[]
for r in allrows:
    t=r['timestamp']; uid=r['user_id']; h=history[uid]
    while h and (t-h[0]['timestamp']).total_seconds()>30*86400: h.popleft()
    prev24=[e for e in h if (t-e['timestamp']).total_seconds()<=86400]
    prev7=[e for e in h if (t-e['timestamp']).total_seconds()<=7*86400]
    first_seen.setdefault((uid,r['device_id']),t)
    age=(t-first_seen[(uid,r['device_id'])]).total_seconds()/86400
    enriched.append({**r,'timestamp':t.isoformat(), 'hour':t.hour,'day_of_week':t.weekday(),
        'avg_amount_30d':round(float(np.mean([e['amount'] for e in h])),2) if h else 0.0,
        'tx_count_24h':len(prev24),'tx_count_7d':len(prev7),
        'distinct_merchants_7d':len({e['merchant_id'] for e in prev7}),
        'distinct_countries_30d':len({e['country'] for e in h}),
        'device_age_days':round(age,4),'is_new_device':int(age<7),'is_night_tx':int(t.hour<=5),
        'history_count_30d':len(h)})
    h.append(r)
all_df=pd.DataFrame(enriched)
ids={r['transaction_id'] for r in target}
df=all_df[all_df.transaction_id.isin(ids)].copy().reset_index(drop=True)
df['split']=['train']*5000+['validation']*1000+['test']*1000
# Independent basic invariants
assert len(df)==N and df.transaction_id.is_unique
assert not df.isna().any().any()
assert (df.tx_count_7d>=df.tx_count_24h).all()
assert (df.distinct_merchants_7d<=df.tx_count_7d).all()
assert (df.distinct_countries_30d<=df.history_count_30d).all()
assert (df.is_new_device==(df.device_age_days<7).astype(int)).all()
assert (df.is_night_tx==(df.hour<=5).astype(int)).all()
assert df.timestamp.is_monotonic_increasing
assert df.groupby('split').size().to_dict()=={'train':5000,'validation':1000,'test':1000}
assert df.is_fraud.nunique()==2
# Persist full preceding history for audit and regeneration.
pd.DataFrame([{**r,'timestamp':r['timestamp'].isoformat()} for r in pre]).to_csv(OUT/'warmup_history.csv',index=False)
df.to_csv(OUT/'transactions_v3.csv',index=False)
for name in ['train','validation','test']:
    df[df.split==name].to_csv(OUT/f'{name}.csv',index=False)
report={'seed':SEED,'target_rows':N,'warmup_rows':len(pre),'unique_users':int(df.user_id.nunique()),
    'fraud_count':int(df.is_fraud.sum()),'fraud_rate':round(float(df.is_fraud.mean()),5),
    'fraud_by_split':df.groupby('split').is_fraud.agg(['sum','mean']).round(5).to_dict('index'),
    'timestamp_start':str(df.timestamp.iloc[0]),'timestamp_end':str(df.timestamp.iloc[-1]),
    'logical_contradictions':0,'missing_values':0,'duplicate_transaction_ids':0,
    'notes':['All historical features use only earlier events; current transaction excluded.',
             'Synthetic fraud labels are simulated, not real-world ground truth.',
             'A single generator creates all splits; metrics cannot establish external generalization.',
             'UTC hour and night indicator are used; local time zones are not modeled.',
             'Device age is first observed age, not necessarily physical device age.']}
(OUT/'quality_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
